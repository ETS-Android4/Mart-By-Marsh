package com.example.martbymarsh;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SigninActivity extends AppCompatActivity {

    private EditText a1, a2;
    private Button login;
    private TextView forget_pass, sign_up;
    private FirebaseAuth mAuth;
    //DatabaseReference reff;
    private String name, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        mAuth= FirebaseAuth.getInstance();

        //reff = FirebaseDatabase.getInstance().getReference().child("Member");

        a1 = findViewById(R.id.name);
        a2 = findViewById(R.id.password);

        name = a1.getText().toString();
        password = a2.getText().toString();

        login = (Button) findViewById(R.id.try_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = a1.getText().toString().trim();
                password = a2.getText().toString().trim();
                if (name.isEmpty()) {
                    a1.setError("Full name required");
                    a1.requestFocus();
                    return;
                }
                mAuth.signInWithEmailAndPassword(name, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(SigninActivity.this, "Welcome \nPlease Log in to get started!", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(SigninActivity.this , HomeActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(getApplicationContext(), "LOGIN FAILED!", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
        });

        forget_pass = findViewById(R.id.forget_pass_button);
        forget_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//               INSERT Forget password CODE here
                Toast.makeText(SigninActivity.this, "We are working on this feature!", Toast.LENGTH_SHORT).show();
            }
        });

        sign_up = findViewById(R.id.LoginToSignup);
        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SigninActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });
    }
}