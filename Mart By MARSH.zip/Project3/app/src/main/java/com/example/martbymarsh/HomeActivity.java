package com.example.martbymarsh;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.ViewFlipper;
public class HomeActivity extends AppCompatActivity {
    NavigationView nav;
    ActionBarDrawerToggle toggle;
    Toolbar toolbar;
    private DrawerLayout drawer;
    public int a=0;
    ViewFlipper flipper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        // Creating sliding image view


       // toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_menu_24);

        int[] sliderImageId = new int[]{
                R.drawable._07544,R.drawable._45556,R.drawable._792093,R.drawable._07544, R.drawable._793242, R.drawable._805696
        };
        flipper=(ViewFlipper)findViewById(R.id.flipper);

        drawer = findViewById(R.id.drawer);
        nav = (NavigationView)findViewById(R.id.nav_menu);
        toggle = new ActionBarDrawerToggle(this, drawer,R.string.open,R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()){
                    case R.id.menu_home:
                        Toast.makeText(HomeActivity.this, "HOME", Toast.LENGTH_SHORT).show();
                        // Home button makes the display jump to the same activity closing the navigation drawer
                        Intent intent = new Intent(HomeActivity.this , HomeActivity.class);
                        startActivity(intent);
                        drawer.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.menu_help:
                        Intent i=new Intent(HomeActivity.this,ProductDetailPage.class);
                        startActivity(i);
                        drawer.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.user_profile:
                        Intent in=new Intent(HomeActivity.this,UserProfile.class);
                        startActivity(in);
                        drawer.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.history:
                        break;
                }
                return true;
            }
        });

        for (int i=0; i<sliderImageId.length;i++){
            showImage(sliderImageId[i]);
        }
    }

    public void showImage(int img){
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(img);

        flipper.addView(imageView);
        flipper.setFlipInterval(3000);
        flipper.setAutoStart(true);
        flipper.setInAnimation(this, android.R.anim.fade_in);
        flipper.setOutAnimation(this, android.R.anim.fade_out);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (a%2==0){
            drawer.openDrawer(GravityCompat.START);
            a=a+1;
        } else {
            drawer.closeDrawer(GravityCompat.START);
            a=a+1;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}



